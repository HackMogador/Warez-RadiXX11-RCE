================================================================================
           ___         _ ___  ____  ___ _    ___  ___ ___                       
          | _ \__ _ __| (_) \/ /\ \/ / / |  | _ \/ __| __|                      
          |   / _` / _` | |>  <  >  <| | |  |   / (__| _|                       
          |_|_\__,_\__,_|_/_/\_\/_/\_\_|_|  |_|_\\___|___|  [ 2022 ]            
                                                                                
=====================| https://radixx11rce3.blogspot.com |======================
                                                                                
____________                                                                    
RELEASE INFO                                                                    
������������                                                                    
. Name......: Raimersoft Products Activator                                     
. Date......: 2022-12-27                                                        
. Version...: 1.0                                                               
. File......: Activator.exe                                                     
. MD5.......: CC7B8610E4213E7426BEB30E97150B5F                                  
. SHA1......: 580483C1FE2EA79A952831FB2522318D01EFE29B                          
                                                                                
___________                                                                     
TARGET INFO                                                                     
�����������                                                                     
. Category..: Internet Radio                                                    
. Protection: Custom/License File                                               
. OS........: WinALL                                                            
. Homepage..: https://www.raimersoft.com                                        
                                                                                
__________________                                                              
TARGET DESCRIPTION                                                              
������������������                                                              
. RadioMaximus: RadioMaximus allows you to listen to and record radio stations  
from around the world.                                                          
                                                                                
. RarmaRadio: RarmaRadio allows you to listen to and record radio stations from 
around the world. Powered by a world class radio directory it has everything you
need for a wonderful listening experience. Recording is available in many       
formats - including mp3, wma and ogg.                                           
                                                                                
. TapinRadio: TapinRadio is a simple internet radio player.                     
                                                                                
__________                                                                      
HOW TO USE                                                                      
����������                                                                      
1. Select the desired product.                                                  
2. Select the installation mode you chose when you installed the program: Normal
or Portable.                                                                    
3. Select the program platform: x86/x64 (should match with your OS platform     
too).                                                                           
4. Enter any name and e-mail you want.                                          
5. Click "Activate". At this point, if you picked Portable mode, the activator  
will ask you to select the folder containing the portable version of the        
program.                                                                        
6. Done.                                                                        
                                                                                
___________________________                                                     
ANTIVIRUS & FALSE POSITIVES                                                     
���������������������������                                                     
Some antivirus can detect this release as a threat and try to remove it. The    
reason for this is because my releases are packed/protected in order to reduce  
its size and avoid alterations to the code. This protection can be erroneously  
identified as a threat, it is what is commonly known as a FALSE POSITIVE. Just  
ignore it, it is safe to use.                                                   
                                                                                
IMPORTANT: there will be no risk when using my releases as long as you have     
downloaded it from the links posted on my site or from the "Check for Updates"  
option. If you have downloaded this release from another site, I CANNOT         
GUARANTEE ITS INTEGRITY. In such case, I will not take responsability for       
eventual problems that arise when using it. Be careful!                         
                                                                                
As a precaution, always check the release hashes.                               
                                                                                
__________                                                                      
DISCLAIMER                                                                      
����������                                                                      
This release is provided AS IS for FOR EVALUATION PURPOSES ONLY! If you can     
afford the software, please BUY IT. Support the developer to make a better      
product.                                                                        
