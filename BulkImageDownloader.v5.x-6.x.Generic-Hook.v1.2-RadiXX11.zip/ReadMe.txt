================================================================================
           ___         _ ___  ____  ___ _    ___  ___ ___                       
          | _ \__ _ __| (_) \/ /\ \/ / / |  | _ \/ __| __|                      
          |   / _` / _` | |>  <  >  <| | |  |   / (__| _|                       
          |_|_\__,_\__,_|_/_/\_\/_/\_\_|_|  |_|_\\___|___|  [ 2021 ]            
                                                                                
=====================| https://radixx11rce3.blogspot.com |======================
                                                                                
____________                                                                    
RELEASE INFO                                                                    
������������                                                                    
. Name...............: BID 5.x/6.x Generic Hook                                          
. Date...............: 2021-11-26                                                        
. Version............: 1.2                                                               
. Installer SHA1.....: 5CC4211246E3BEA94B29C1C895E153D3C04E89D6                          
. Hook DLL SHA1 (x86): 146D6A731E2759ABDA39C2312BA87C191EF87998                          
. Hook DLL SHA1 (x64): 95E16C8492653A9870449D822BA4A4FE531E08F3                          
                                                                                
___________                                                                     
TARGET INFO                                                                     
�����������                                                                     
. Category..: Download Managers                                                 
. Protection: Obsidium+Custom                                                   
. OS........: WinALL                                                            
. Homepage..: https://bulkimagedownloader.com                                   
                                                                                
__________________                                                              
TARGET DESCRIPTION                                                              
������������������                                                              
Bulk Image Downloader (BID) is a simple to use yet powerful image downloading   
tool for Windows PCs.                                                           
                                                                                
Apart from simply downloading all the images on a web page it can also locate   
and download full sized images from almost any thumbnailed web gallery. A       
thumbnailed web gallery is a web page containing thumbnailed (small sized)      
images that each link to full sized images or to secondary pages containing the 
full sized images.                                                              
                                                                                
To download all of the full sized images from such pages you would typically    
need to click on each thumbnailed link and then right click on each full sized  
image and select "Save Image As...", which can be difficult and time consuming. 
                                                                                
BID makes downloading full sized images from such galleries quick and easy. BID 
will automatically download from almost any site, even if the images are hosted 
on free image hosting sites such as flickr, imagevenue or imagefap. It is smart 
enough to handle most sites without any complicated set up or "project files"   
required. It just works.                                                        
                                                                                
BID is not just for images - it can also download thumbnailed video files from  
pages that contain directly linked video files (.mp4, .avi, .wmv, .mpeg, .mov,  
etc.)                                                                           
                                                                                
__________                                                                      
HOW TO USE                                                                      
����������                                                                      
1. Install BID but do not run it yet.                                           
                                                                                
2. Run the provided installer and follow the instructions to install/repair or  
   uninstall/upgrade the hook in your system.                                   
                                                                                
_____________________                                                           
IMPORTANT (MUST READ)                                                           
���������������������                                                           
. It is advisable that you always run this installer outside of the installation
folder of the target program. If possible, the installer will detect where the  
program was installed, but also you will be able to specify the location        
manually if needed.                                                             
                                                                                
. In case you have a previous version of the hook, the installer will detect it 
and will offer you the chance to upgrade it to this newer version without need  
to manually remove the old one.                                                 
                                                                                
. If you have any issues with the program after installing the hook (it crashes 
or it remains in free mode), try the following:                                 
                                                                                
- If you have DEP enabled, add the program to the exclusion list.               
- If you have any Antivirus/Anti-Malware program, add the program/folder to the 
  exclusion list.                                                               
- Run the hook installer to detect any possible misconfiguration or missing file
  and repair it.                                                                
                                                                                
If none of the above works, probably it's necessary to update this fix.         
                                                                                
______________                                                                  
NEWS & UPDATES                                                                  
��������������                                                                  
In almost all my releases you will find an "Options" menu. This menu can be     
opened by cliking the little button with a down-arrow icon (upper-right corner  
of the main window) or with a "stack" icon (lower-right corner of the main      
window), depending on the release. This menu has two useful options:            
                                                                                
. News & Announcements: This option allows to check for the latest news         
  regarding to my site or any other important announcement.                     
                                                                                
. Check for Updates: This option allows to verify if there is a new version of  
  this release, check its changelog and download the new version directly.      
  Almost at the same time you will find the new version also posted on my site. 
                                                                                
NOTE: These options require an Internet connection in order to work. In case    
you have a firewall, probably you will need to make an exception.               
                                                                                
___________________________                                                     
ANTIVIRUS & FALSE POSITIVES                                                     
���������������������������                                                     
Some antivirus can detect this release as a threat and try to remove it. The    
reason for this is because my releases are packed/protected in order to reduce  
its size and avoid alterations to the code. This protection can be erroneously  
identified as a threat, it is what is commonly known as a FALSE POSITIVE. Just  
ignore it, it is safe to use.                                                   
                                                                                
IMPORTANT: there will be no risk when using my releases as long as you have     
downloaded it from the links posted on my site or from the "Check for Updates"  
option. If you have downloaded this release from another site, I CANNOT         
GUARANTEE ITS INTEGRITY. In such case, I will not take responsability for       
eventual problems that arise when using it. Be careful!                         
                                                                                
As a precaution, always check the release hashes.                               
                                                                                
__________                                                                      
DISCLAIMER                                                                      
����������                                                                      
This release is provided AS IS for FOR EVALUATION PURPOSES ONLY! If you can     
afford the software, please BUY IT. Support the developer to make a better      
product.                                                                        
